package pa7.table;

/**
 * Marks styling to use in GUI display
 */
public enum PACellType {
    CELL_WHITE, COL_HEADER, ROW_HEADER, CELL_GRAY, CELL_BLACK, TITLE, CORNER
}
